/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helperpackage;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;

/**
 *
 * @author Felipe Corona
 */
public class MultipleProductWriter {
    
    public static void write(Iterable<Integer> productList, PrintWriter out) throws SQLException, 
            InstantiationException, IllegalAccessException, ClassNotFoundException{
        
        
        try (Connection dbcon = getConnection()) {
            displayProducts(out, dbcon, productList);
        }
        
    }
    
    private static Connection getConnection() throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
	return DriverManager.getConnection(MyConstants.SQL_URL, MyConstants.USERNAME, MyConstants.PASSWORD);
    }
    
    private static void displayProducts(PrintWriter out, Connection conn, Iterable<Integer> productList) throws SQLException{
        out.println("<table class='sales-list'>");
        
        Iterator<Integer> it = productList.iterator();
        while (it.hasNext()){
            String sqlQuery = "SELECT * FROM products WHERE id = ? ";
            
            Integer productID1 = it.next();
            Integer productID2 = null;
            Integer productID3 = null;
            if (it.hasNext()) {
                productID2 = it.next();
                sqlQuery += "OR id = ? ";
            }
            if (it.hasNext()) {
                productID3 = it.next();
                sqlQuery += "OR id = ?";
            }
            
            PreparedStatement statement = conn.prepareStatement(sqlQuery);
            statement.setInt(1, productID1);
            if (productID2 != null) {
                statement.setInt(2, productID2);
            }
            if (productID3 != null) {
                statement.setInt(3, productID3);
            }
            
            ResultSet rs = statement.executeQuery();
            displayTitle(out, rs);
            rs = statement.executeQuery();
            displayPicture(out, rs);
            rs = statement.executeQuery();
            displayDetail(out, conn, rs);
            rs = statement.executeQuery();
            displayPrice(out, rs);
            
            statement.close();
        }
        

        out.println("</table>");
    }
    
    private static void displayTitle(PrintWriter out, ResultSet rs) throws SQLException {
        out.println("<tr>");
        
        while(rs.next()){
            out.println("<td><h2>");
            out.println(rs.getString("title"));
            out.println("</h2></td>");
        }
        
        out.println("</tr>");
    }
    
    private static void displayPicture(PrintWriter out, ResultSet rs) throws SQLException{
        out.println("<tr>");
        
        while(rs.next()){
            out.println("<td><a href='/EzPCzy3/product?id=" + rs.getString("id") + "'>");
            out.println("<img src='" + rs.getString("primary_pic") + "' alt='" + rs.getString("title") + "'/>");
            out.println("</a></td>");
        }
        out.println("</tr>");
    }
    
    private static void displayDetail(PrintWriter out, Connection conn, ResultSet rs) throws SQLException{
        out.println("<tr>");
        
        while(rs.next()) {
            out.println("<td><div class='sales-item'><table>");
            out.println("<tr><td class='sales-item-key'>Type</td>");
            out.println("<td class='sales-item-value'>" + rs.getString("type") + "</td></tr>");
            out.println("<tr><td class='sales-item-key'>Brand</td>");
            out.println("<td class='sales-item-value'>" + rs.getString("brand") + "</td></tr>");
            out.println("<tr><td class='sales-item-key'>Specs</td>");
            out.println("<td class='sales-item-value'><ul>");

            displayDescriptionsForItem(out, conn, rs.getString("id"));

            out.println("</ul></td></tr></table></div></td>");
        }
        
        out.println("</tr>");
    }
    
    
    private static void displayDescriptionsForItem(PrintWriter out, Connection conn, String productID) throws SQLException{
        Statement statement = conn.createStatement();
        ResultSet rs = statement.executeQuery("SELECT description FROM descriptions WHERE main_spec='TRUE' AND id='" + productID + "';");
        
        while(rs.next()){
            out.println("<li>" + rs.getString("description") + "</li>");
        }
        statement.close();
    }
    
    private static void displayPrice(PrintWriter out, ResultSet rs) throws SQLException{
        out.println("<tr>");
        
        while(rs.next()) {
            out.println("<td><h3>$" + rs.getString("price") + "</h3></td>");
        }
        out.println("</tr>");
    }
}
