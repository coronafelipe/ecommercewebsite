/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helperpackage;

/**
 *
 * @author Felipe Corona
 */
public final class MyConstants {
    	// MySQL Username
	public static final String USERNAME = "inf124grp29";
	
	// MySQL Password
	public static final String PASSWORD = "y2brExa+";
	
	// DATABASE URL
	public static final String SQL_URL = "jdbc:mysql://sylvester-mccoy-v3.ics.uci.edu:3306/inf124grp29";
}
