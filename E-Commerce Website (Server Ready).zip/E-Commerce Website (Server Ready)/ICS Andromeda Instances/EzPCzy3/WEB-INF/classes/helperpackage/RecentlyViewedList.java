/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helperpackage;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Felipe
 * A data structure that holds DEFAULT_MAX_ITEMS, and is ordered ascending
 * by time added, and does not contain duplicates
 */
public class RecentlyViewedList implements Iterable<Integer>{
    
    public static final int DEFAULT_MAX_ITEMS = 5;
    
    private ArrayList<Integer> items;
    private int maxItems;
    
    public RecentlyViewedList(){
        items = new ArrayList<Integer>();
        maxItems = DEFAULT_MAX_ITEMS;
    }
    
    public void add(int productID){
        //If the list already contains it, remove it ...
        if (items.contains(productID)) {
            //to prevent duplicates
            items.remove(items.indexOf(productID));
        }
        //else if the list is full, remove the oldest...
        else if (items.size() == 5){
            items.remove(0);
        }
        //then add the new product to the end
        items.add(productID);
    }
    
    public int size(){
        return items.size();
    }
    
    public boolean isEmpty() {
        return items.isEmpty();
    }

    @Override
    public Iterator<Integer> iterator() {
        return items.iterator(); 
    }
}
