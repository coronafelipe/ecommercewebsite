/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helperpackage;

import java.io.PrintWriter;

/**
 *
 * @author Felipe Corona
 */
public class Func_Redirector {
    // Force user to go back a page
    public static void goBack(PrintWriter out) {
         out.println("<script>window.history.back();</script>");
    }
    
    // Redirect user to specified page
    public static void goToSite(PrintWriter out, String site, String redirectionMessage) {
        out.println("<HTML>");
        out.println("	<head>");
        out.println("		<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />");
        out.println("		<meta HTTP-EQUIV='REFRESH' content='0; url=" + site + "'>");
        out.println("		<TITLE>" + redirectionMessage + "</TITLE>");
        out.println("	</head>");
        out.println("	<body>");
        out.println("	</body>");
        out.println("</HTML>");
    }
    
    // Replace current URL with new one
    public static void goToSiteReplace(PrintWriter out, String site) {
        out.println("<script>window.location.replace('" + site + "')</script>");
    }
}
