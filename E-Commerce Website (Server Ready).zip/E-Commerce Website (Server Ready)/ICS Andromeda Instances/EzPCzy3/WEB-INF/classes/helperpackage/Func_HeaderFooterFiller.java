/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helperpackage;

import java.io.PrintWriter;

/**
 *
 * @author Felipe Corona
 */
public class Func_HeaderFooterFiller {
    
    /*
    Insert an array of path to CSS files for parameter 2
    Insert an array of path to JS files for parameter 3
    Example: fillHead(out, ["CSS/master.css"], ["JS/eventhandlers.js"]);
    */
    public static void fillHead(PrintWriter out, String[] css, String[] js) {
        out.println("<html>");
        out.println("    <head>");
        out.println("        <title>EzPCzy</title>");
        out.println("        <meta charset='UTF-8'>");
        out.println("        <meta name='viewport' content='width=device-width, initial-scale=1.0'>");     
        for (String styles : css) {
            out.println("        <link rel='stylesheet' href='" + styles + "' type='text/css'>");
        }   
        for (String javascript : js) {
            out.println("        <script language='javascript' type='text/javascript' src='" + javascript + "'></script>");
        }
        out.println("    </head>");            
    }
    
    
    public static void fillHeader(PrintWriter out) {
        out.println("    <body>");
        out.println("        <header>");
        out.println("            <h2>EzPCzy</h2>");
        out.println("            <hr>");
        out.println("            <img src='images/logo.png' alt='EzPCzy'/>");
        out.println("            <nav>");
        out.println("                <a href='index.jsp'>Home</a>");
        out.println("                <a href='products' id='productDropdown'>Products</a>");
        out.println("                <a href='checkout'>My Cart</a>");
        out.println("                <a href='about.html'>About</a>");
        out.println("                <a href='theteam.html'>The Team</a>");
        out.println("                <a href='contactus.html'>Contact Us</a>");
        out.println("                <table id='headerNavDropdown' cellspacing='0' cellpadding='0'>");
        out.println("                    <tr>");
        out.println("                        <td></td>");
        out.println("                        <td align='center'><a href='products?products=laptops' class='headerDropdown'>Laptops</a></td>");
        out.println("                        <td></td>");
        out.println("                        <td></td>");
        out.println("                        <td></td>");
        out.println("                        <td></td>");
        out.println("                    </tr>");
        out.println("                    <tr>");
        out.println("                        <td></td>");
        out.println("                        <td align='center'><a href='products?products=desktops' class='headerDropdown'>Desktops</a></td>");
        out.println("                        <td></td>");
        out.println("                        <td></td>");
        out.println("                        <td></td>");
        out.println("                        <td></td>");
        out.println("                    </tr>");
        out.println("                    <tr>");
        out.println("                        <td></td>");
        out.println("                        <td align='center'><a href='products?products=accessories' class='headerDropdown'>Accessories</a></td>");
        out.println("                        <td></td>");
        out.println("                        <td></td>");
        out.println("                        <td></td>");
        out.println("                        <td></td>");
        out.println("                    </tr>");
        out.println("                </table>");
        out.println("            </nav>");
        out.println("        </header>");
    }
    
    
    public static void fillFooter(PrintWriter out) {     
       out.println("        <footer>");
       out.println("            <p>© 2016 CS 137 Group 29, Inc.</p>");
       out.println("            <nav>");
       out.println("                <a href=\"privacy-policy.html\">Privacy Policy</a>");
       out.println("                <a href=\"terms-and-conditions.html\">Terms and Conditions</a>");
       out.println("            </nav>");
       out.println("        </footer>");
       out.println("    </body>");
       out.println("</html>");
    }
}
