/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.ServletContext;
import java.sql.*;
import java.util.*;
//import java.lang.String;
import helperpackage.*;


/**
 *
 * @author Felipe Corona
 */
public class ProductServlet extends HttpServlet {
    private Connection getConnection() throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
	return DriverManager.getConnection(MyConstants.SQL_URL, MyConstants.USERNAME, MyConstants.PASSWORD);
        
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
{       
        ServletContext ctx = getServletContext();
        HttpSession session = request.getSession(true);
        session.setMaxInactiveInterval(300);
        Connection dbcon = null;
        PrintWriter out = null;
        PreparedStatement ps = null;
        PreparedStatement ps_updateClicks = null;
        ResultSet rs = null;
        
        try {
            String parameter = request.getParameter("id");
            response.setContentType("text/html;charset=UTF-8");
            out = response.getWriter();
            
            Func_HeaderFooterFiller.fillHead(out, new String[]{"CSS/master.css", "CSS/sales.css"}, new String[]{"JS/eventhandlers.js", "JS/productdetails.js"});
            Func_HeaderFooterFiller.fillHeader(out);
            out.println("<div class=\"container\">");
            out.println("<div class=\"sale\">");
            
            // Check if parameter is int
            boolean validID = Func_ParseHelper.stringIsInt(parameter);
            
            if (validID && Integer.parseInt(parameter) > 0) {
                // Store User ID Into ServletContext and products they're viewing
                String userID = session.getId();
                HashMap<String, HashSet<Integer>> session_list = (HashMap<String,HashSet<Integer>>)ctx.getAttribute("session_list");
                if (session_list == null) {
                    session_list = new HashMap<>();
                } 
                if (!session_list.containsKey(userID)) {
                    session_list.put(userID, new HashSet<Integer>());
                }
                HashSet<Integer> userViewProducts = session_list.get(userID);
                userViewProducts.add(Integer.parseInt(parameter));
                session_list.put(userID, userViewProducts);
                ctx.setAttribute("session_list", session_list);
                
                dbcon = getConnection();
                ps = dbcon.prepareStatement("SELECT * FROM products p INNER JOIN (SELECT id, description FROM descriptions) AS X ON p.id = X.id AND X.id = ?");
                ps.setString(1, parameter);
                rs = ps.executeQuery();

                // Show Total 
                int count = 0;
                for (HashSet<Integer> usersViewingProducts : session_list.values()) {
                    if (usersViewingProducts.contains(Integer.parseInt(parameter))) {
                        count++;
                    }
                }
                out.print("<br>Users Viewing: " + count);  

                if (rs.next()) {
                    rs.previous();
                    //Ben's function to update clicks for hottest items
                    ps_updateClicks = dbcon.prepareStatement("UPDATE products SET clicks = clicks + 1 WHERE id=?");
                    ps_updateClicks.setString(1, parameter);
                    ps_updateClicks.executeUpdate();
                   
                    //kevin's function to update recently viewed items
                    addToRecentlyViewed(request.getSession(), Integer.parseInt(parameter));
                    
                    while (rs.next()) {
                            out.println("<h1>" + rs.getString("title") + "</h1>");
                            out.println("<img id=\"sale-product-img\" src='" + rs.getString("primary_pic") + "' alt=\"" + rs.getString("title") + "\"/>");
                            out.println("<br/>");
                            out.println("<a href='AddToCart?id=" + rs.getString("id") + "'>");
                            out.println("<img id='buy-button' src= 'images/buy.png' alt='ADD TO CART'/>"); // REPLACE THIS WITH ADD TO CART
                            out.println("</a>");
                            out.println("<h2>$"+rs.getString("price") + "</h2>");
                            out.println("<div class=\"sales-item\">");
                            out.println("<table>");
                            out.println("<tr>");
                            out.println("<td class=\"sales-item-key\">Product ID</td>");
                            out.println("<td class=\"sales-item-value\">" + rs.getString("id") + "</td>");
                            out.println("</tr>");
                            out.println("<table>");
                            out.println("<br/>");
                            out.println("<table>");
                            out.println("<tr>");
                            out.println("<td class=\"sales-item-key\">Type</td>");
                            out.println("<td class=\"sales-item-value\">Desktops</td>");
                            out.println("</tr>");
                            out.println("<tr>");
                            out.println("<td class=\"sales-item-key\">Brand</td>");
                            out.println("<td class=\"sales-item-value\">" + rs.getString("brand") + "</td>");
                            out.println("</tr>");
                            out.println("<tr>");
                            out.println("<td class=\"sales-item-key\">Specs");
                            out.println("<td class=\"sales-item-value\">");
                            out.println("<ul>");
                            out.println("<li>" + rs.getString("description") + "</li>");
//                          displayDescription = true;

                        while(rs.next()){
                            out.println("<li>" + rs.getString("description") + "</li>");
                        }
                        out.println("</ul>");
                        out.println("</td>");
                        out.println("</tr>");
                        out.println("</table>");
                        out.println("<br/><br/>");
                        rs.previous();
                        out.println("<table id=\"sale-imgs\">");
                        out.println("<tr>");
                        out.println("<td>");
                        out.println("<img class=\"sale-img\" src=" + rs.getString("primary_pic")+ " alt=\"sale item\"/>");
                        out.println("</td>");
                        out.println("<td>");
                        out.println("<img class=\"sale-img\" src=" + rs.getString("pic1")+ " alt=\"sale item\"/>");
                        out.println("</td>");
                        out.println("<td>");
                        out.println("<img class=\"sale-img\" src=" + rs.getString("pic2")+ " alt=\"sale item\"/>");
                        out.println("</td>");
                        out.println("<td>");
                        out.println("<img class=\"sale-img\" src=" + rs.getString("pic3")+ " alt=\"sale item\"/>");
                        out.println("</td>");
                        out.println("<td>");
                        out.println("<img class=\"sale-img\" src=" + rs.getString("pic4")+ " alt=\"sale item\"/>");
                        out.println("</td>");
                        out.println("</tr>");
                        out.println("</table>");
                        out.println("</div>");
                        out.println("</div>");                
                    }                
                } else {
                    Func_NotAvailable.productNotAvailable(out);
                }
            } else {
                Func_NotAvailable.productNotAvailable(out);
            }

            out.println("</div>");
            out.println("<br/><br/><br/><br/>");
            
            
            Func_HeaderFooterFiller.fillFooter(out);
        } catch (Exception ex) {
            out.println("ERROR: " + ex);
        } 
        finally {
            if (rs != null) {try {rs.close();} catch (SQLException e) {}}
            if (ps != null) {try {ps.close();} catch (SQLException e) {}}
            if (ps_updateClicks != null) {try {ps_updateClicks.close();} catch (SQLException e) {}}
            if (dbcon != null) {try {dbcon.close();} catch (SQLException e) {}}
            if (out != null) {out.close();}
        
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    
    private void addToRecentlyViewed(HttpSession session, int productID){
        RecentlyViewedList recentlyViewed = (RecentlyViewedList) session.getAttribute("recentlyViewed");
        if (recentlyViewed == null)  {
            recentlyViewed = new RecentlyViewedList();
            session.setAttribute("recentlyViewed", recentlyViewed);
        }
        
        recentlyViewed.add(productID);
    }
}