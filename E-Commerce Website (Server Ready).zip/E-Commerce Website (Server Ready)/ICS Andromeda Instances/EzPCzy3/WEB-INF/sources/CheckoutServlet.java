/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import helperpackage.*;
import javax.servlet.http.*;
import java.util.*;

/**
 *
 * @author Felipe Corona
 */
public class CheckoutServlet extends HttpServlet {

    // Create New Connection
    private Connection getConnection() throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
    	Class.forName("com.mysql.jdbc.Driver").newInstance();
        return DriverManager.getConnection(MyConstants.SQL_URL, MyConstants.USERNAME, MyConstants.PASSWORD);
    }	
	
    // Process Request
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        Connection dbcon = null;
        PrintWriter out = null;
		
	try {   
            response.setContentType("text/html;charset=UTF-8");
            out = response.getWriter();
            
            dbcon = getConnection();
            
            Func_HeaderFooterFiller.fillHead(out, new String[]{"CSS/master.css", "CSS/form.css"}, new String[]{"JS/eventhandlers.js", "JS/order-form-info-handler.js"});
            Func_HeaderFooterFiller.fillHeader(out);
            out.println("<div class=\"container\">");
            
            // CHECKOUT
            showItemsInCart(request, response, out, dbcon);
            
            out.println("<br/><br/><br/><br/>");
            out.println("</div>");
            Func_HeaderFooterFiller.fillFooter(out);
//            refreshPageForInfo(request, response, out);
        } catch (IOException | SQLException | InstantiationException | IllegalAccessException | ClassNotFoundException | ServletException ex) {
//            out.println("ERROR: " + ex);
        } finally {
            if (dbcon != null) {try {dbcon.close();} catch (SQLException e) {}}
            if (out != null) {out.close();}
        }
    }
    
    protected void showItemsInCart(HttpServletRequest request, HttpServletResponse response, PrintWriter out, Connection dbcon) 
            throws IOException, ServletException {
        
        HttpSession session = request.getSession(true);
        session.setMaxInactiveInterval(900);
        
        HashMap<Integer, Integer> itemsInCart = (HashMap<Integer,Integer>)session.getAttribute("itemsInCart");
        if (itemsInCart == null) {
            itemsInCart = new HashMap<>();
            session.setAttribute("itemsInCart", itemsInCart);
        }
        HashMap<String, String> tempOrderInfo = (HashMap<String, String>)session.getAttribute("tempOrderInfo");
        
        // Begin filling form
        out.println("            <form action='order-details' method='post' autocomplete='on'>");
        out.println("                <h1>My Cart</h1>");
        out.println("                <table id='shopping-cart'>");
        out.println("                    <tr>");
        out.println("                        <td><h4>Product</h4></td>");
        out.println("                        <td><h4>Price</h4></td>");
        out.println("                        <td><h4>Quantity</h4></td>");
        out.println("                    </tr>");
        // Iterate through itemsInCart and start displaying
        double price = iterateItemsInCart(request, response, out, dbcon, itemsInCart);
        out.println("                </table>");
        out.println("                <br/>");
        out.println("                <input type='submit' name='update' value='Update Shopping Cart'>");
        out.println("                <br/><br/>");
        // Display Price to Users
        displayPriceToUsers(request, response, out, tempOrderInfo, price);
        // Display Form to Users to fill out their information
        displayUserInputs(request, response, out, tempOrderInfo, dbcon);
        out.println("                <br/><br/>");
        out.println("                <input type='submit' name='submit' value='Submit'>");
        out.println("            </form>");
        
        session.setAttribute("tempOrderInfo", null);
    }
    
    // returns price of all items in cart added together
    protected double iterateItemsInCart(HttpServletRequest request, HttpServletResponse response, PrintWriter out, Connection dbcon, HashMap<Integer, Integer> itemsInCart) 
            throws IOException, ServletException {
        double totalprice = 0;
        
        String sql = "SELECT id, title, price FROM products WHERE id=-1";
        for (Integer productID : itemsInCart.keySet()) {
            sql += " OR id=" + productID;
        }
        
        Statement stmt = null;
        ResultSet rs = null;
        try {
            stmt = dbcon.createStatement();
            rs = stmt.executeQuery(sql);
            
            while (rs.next()) {
                double price = rs.getDouble("price");
                price = price * itemsInCart.get(rs.getInt("id"));
                totalprice += price;
                
                String title = rs.getString("title");
                if (title.length() > 100) {
                    title = title.substring(0, 100) + "...";
                }
                out.println("                    <tr>");
                out.println("                        <td><p class='shopping-cart-title'>" + title + "</p></td>");
                out.println("                        <td><p>$" + rs.getString("price") + "</p></td>");
                out.println("                        <td><input type='number' min='0' step='1' value='" + itemsInCart.get(rs.getInt("id")) + "' name='product-" + rs.getString("id") + "' class='product-quantity' id='product-" + rs.getString("id") + "'></td>");
                out.println("                    </tr>");
            }
        } catch (Exception ex) {
            out.println(ex);
        } finally {
            if (rs != null) {try {rs.close();} catch (SQLException e) {}}
            if (stmt != null) {try {stmt.close();} catch (SQLException e) {}}
        }
        return totalprice;
    }
    
    protected void displayPriceToUsers(HttpServletRequest request, HttpServletResponse response, PrintWriter out, HashMap<String, String> tempOrderInfo, double price) 
            throws IOException, ServletException {
        double totalprice = price;
        if (tempOrderInfo != null) {
            try {
                double shippingPrice = Double.parseDouble(tempOrderInfo.get("shippingMethod")); // won't change if it fails
                totalprice += shippingPrice;
            } catch (Exception ex) {};
        }
        out.printf("                <input type='hidden' id='price' name='price' value='%.2f'>\n", price);
        out.printf("                <input type='hidden' id='totalprice' name='totalprice' value='%.2f'>\n", totalprice);
        out.printf("                <h3 id='form-product-totalprice'>Total Price: $%.2f</h3><br/>\n", totalprice);
    }
    
    protected void displayUserInputs(HttpServletRequest request, HttpServletResponse response, PrintWriter out, HashMap<String, String> tempOrderInfo, Connection dbcon) 
            throws IOException, ServletException {
        String tempInput;
        
        out.println("                <table id='form-user-order'>");
        out.println("                    <tr>");
        out.println("                        <td><p>First Name:</p></td>");
        tempInput = "                        <td class='form-input'><input type='text' name='firstname'";
        if (tempOrderInfo != null)
            tempInput += " value='" + tempOrderInfo.get("firstname") + "'";
        out.println(tempInput + "></td>");
        out.println("                    </tr>");
        out.println("                    <tr>");
        out.println("                        <td><p>Last Name:</p></td>");
        tempInput = "                        <td class='form-input'><input type='text' name='lastname'";
        if (tempOrderInfo != null)
            tempInput += " value='" + tempOrderInfo.get("lastname") + "'";
        out.println(tempInput + "></td>");
        out.println("                    </tr>");
        out.println("                    <tr>");
        out.println("                        <td><p>Phone Number:</p></td>");
        tempInput = "                        <td class='form-input'><input type='text' name='phone'";
        if (tempOrderInfo != null)
            tempInput += " value='" + tempOrderInfo.get("phone") + "'";
        out.println(tempInput + "></td>");
        out.println("                    </tr>");
        out.println("                    <tr>");
        out.println("                        <td><p>Email Address:</p></td>");
        tempInput = "                        <td class='form-input'><input type='text' name='email'";
        if (tempOrderInfo != null)
            tempInput += " value='" + tempOrderInfo.get("email") + "'";
        out.println(tempInput + "></td>");
        out.println("                    </tr>");
        out.println("                    <tr>");
        out.println("                        <td><br></td>");
        out.println("                        <td><br></td>");
        out.println("                    </tr>");
        out.println("                    <tr>");
        out.println("                        <td><p>Shipping Address: </p></td>");
        tempInput = "                        <td class='form-input'><input type='text' name='shippingAddress'";
        if (tempOrderInfo != null)
            tempInput += " value='" + tempOrderInfo.get("shippingAddress") + "'";
        out.println(tempInput + "></td>");
        out.println("                    </tr>");
        out.println("                    <tr>");
        out.println("                        <td><p>Zip Code: </p></td>");
        tempInput = "                        <td class='form-input'><input id='zipCode' type='number' name='zipCode' min='0' max='99999'";
        if (tempOrderInfo != null)
            tempInput += " value='" + tempOrderInfo.get("zipCode") + "'";
        out.println(tempInput + "></td>");
        out.println("                    </tr>");
        out.println("                    <tr>");
        out.println("                        <td><p>City: </p></td>");
        tempInput = "                        <td class='form-input'><input id='city' type='text' name='city'";
        if (tempOrderInfo != null)
            tempInput += " value='" + tempOrderInfo.get("city") + "'";
        out.println(tempInput + "></td>");
        out.println("                    </tr>");
        out.println("                    <tr>");
        out.println("                        <td><p>State: </p></td>");
        out.println("                        <td class='form-input'>");
        out.println("                            <select id='state' name='state'>");
        // Print all states option values
        printAllStates(request, response, out, dbcon, tempOrderInfo);
        out.println("                            </select>");
        out.println("                        </td>");
        out.println("                    </tr>");
        out.println("                    <tr>");
        out.println("                        <td><br></td>");
        out.println("                        <td><br></td>");
        out.println("                    </tr>");
        out.println("                    <tr>");
        out.println("                        <td><p>Credit Card Number: </p></td>");
        tempInput = "                        <td class='form-input'><input type='text' name='creditCard'";
        if (tempOrderInfo != null)
            tempInput += " value='" + tempOrderInfo.get("creditCard") + "'";
        out.println(tempInput + "></td>");
        out.println("                    </tr>");
        out.println("                    <tr>");
        out.println("                        <td><p>Shipping Method: </p></td>");
        out.println("                        <td class='form-input'>");
        String shipping1 = "                            <input type='radio' class='shippingMethod' name='shippingMethod' value='0' onchange='calculateShipping()' ";
        String shipping2 = "                            <input type='radio' class='shippingMethod' name='shippingMethod' value='4.99' onchange='calculateShipping()' ";
        String shipping3 = "                            <input type='radio' class='shippingMethod' name='shippingMethod' value='9.99' onchange='calculateShipping()' ";
        if (tempOrderInfo == null) {
            shipping1 += "checked";
        } else {
            switch (tempOrderInfo.get("shippingMethod")) {
                case "0":
                    shipping1 += "checked";
                    break;
                case "4.99":
                    shipping2 += "checked";
                    break;
                case "9.99":
                    shipping3 += "checked";
                    break;
                default:
                    break;
            }
        }
        out.println(shipping1 + "> 6-days ground (Free)<br>");
        out.println(shipping2 + "> 2-days Expedited ($4.99)<br>");
        out.println(shipping3 + "> Overnight ($9.99)");
        out.println("                        </td>");
        out.println("                    </tr>");
        out.println("                </table>");
    }
    
    protected void printAllStates(HttpServletRequest request, HttpServletResponse response, PrintWriter out, Connection dbcon, HashMap<String,String> tempOrderInfo) 
            throws IOException, ServletException {
        Statement stmt = null;
        ResultSet rs = null;
        
        String tempOrderValue = "";
        if (tempOrderInfo != null) {
            if (tempOrderInfo.containsKey("state")) {
                tempOrderValue = tempOrderInfo.get("state");
            }
        }
        
        try {
            stmt = dbcon.createStatement();
            rs = stmt.executeQuery("SELECT DISTINCT state FROM zip_codes ORDER BY state ASC;");
            while (rs.next()) {
                out.print("                                <option value='" + rs.getString("state") + "'");
                if (tempOrderValue.equals(rs.getString("state"))) {
                    out.print(" selected");
                }
                out.println(">" + rs.getString("state") + "</option>");
            }
        } catch (Exception ex) {
//            out.println(ex);
        } finally {
            if (rs != null) {try {rs.close();} catch (SQLException e) {}}
            if (stmt != null) {try {stmt.close();} catch (SQLException e) {}}
        }
    }
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
