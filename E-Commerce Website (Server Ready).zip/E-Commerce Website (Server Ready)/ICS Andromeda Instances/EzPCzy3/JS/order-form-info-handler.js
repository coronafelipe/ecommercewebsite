/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function calculateShipping()
{
    var shippingMethodArray = document.getElementsByName('shippingMethod');
    var currentPrice = document.getElementById("price").value;
    var shippingValue = 0;
    for (var i = 0; i < shippingMethodArray.length; i++) {
        if (shippingMethodArray[i].type === 'radio' && shippingMethodArray[i].checked) {
            shippingValue = shippingMethodArray[i].value;
            break;
        }
    }
    var totalPrice = parseFloat(shippingValue) + parseFloat(currentPrice);
    document.getElementById("totalprice").value = parseFloat(totalPrice).toFixed(2);
    document.getElementById("form-product-totalprice").innerHTML = "Total Price: $" + parseFloat(totalPrice).toFixed(2);
}