You cannot run any of these files on your local instances of Tomcat unless 
you are using Ubuntu 14.04 or something similar.

ICS Andromeda Server instances contain a war file that uses the SQL database 
found on the ICS servers. You can't use it unless you're connected to the ICS 
servers. 

LocalHost Ubuntu Instances contain a war file that uses localhost MySQL server. 
You can't use it if you're on your local machine with Windows or Mac, but if you 
have some server or cloud service such as AWS, you can deploy it and it should 
work if you setup your MySQL database properly.

If you want a working EzPCzy3 instance that you can run on your local host, just 
check the EzPCzy3 folder that was done on Netbeans. That should do. 