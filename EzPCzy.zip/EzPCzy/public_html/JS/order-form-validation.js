/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function submitOrderForm(form)
{
    if (!validProductID(form.productID.value))
    {
        alert("ProductID is not a number");
        return false;
    }
    if (!validQuantity(form.quantity.value))
    {
        alert("Quantity must be a positive integer");
        return false;
    }
    if (!validName(form.firstname.value))
    {
        alert("Not a valid First name format");
        return false;
    }
    if (!validName(form.lastname.value))
    {
        alert("Not a valid Last name format");
        return false;
    }
    if (!validPhoneNumber(form.phone.value))
    {
        alert("Invalid phone number format.\nTry ###-###-####");
        return false;
    }
    if (!validEmail(form.email.value))
    {
        alert("Invalid email format.\nTry something@domain.extension");
        return false;
    }
    if (!validShippingAddress(form.shippingAddress.value))
    {
        alert("Invalid Shipping Address format");
        return false;
    }
    if (!validCreditCardNumber(form.creditCard.value))
    {
        alert("Not a valid credit card number format.\nValid credit cards contain only numbers with length greater than 10.");
        return false;
    }
    return true;
}

function validProductID(id)
{
    return isJustNumbers(id);
}

function validQuantity(quantity)
{
    return parseInt(quantity) > 0;
}

function validName(name)
{
    //not really sure how to validate a name
    return name.length > 0;
}

function validPhoneNumber(phoneNum)
{
    //matches ##########, ###-###-####, (###)###-####, ...
     var phoneRegex = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
     return phoneNum.match(phoneRegex);
}

function validEmail(email)
{
    var regex = /\S+@\S+\.\S+/;
    return email.match(regex);
}

function validShippingAddress(shippingAddress)
{
    //not sure how to validate a shipping address...
    return shippingAddress.length > 0;
}

function validCreditCardNumber(creditCardNum)
{
    //there are many types of credit card formats, so let's
    //just check if it's a long number
    return creditCardNum.length > 10 && !isJustNumbers(id);
}

function isJustNumbers(num)
{
    //isNaN and parseInt are not sufficient....
   var regex = /^\d+$/;
   return num.match(regex);
}