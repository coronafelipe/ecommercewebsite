/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function submitOrderForm(form)
{
    if (!validQuantity(form.quantity.value))
    {
        alert("Quantity must be a positive integer");
        return false;
    }
    if (!validName(form.firstname.value))
    {
        alert("Not a valid First name format");
        return false;
    }
    if (!validName(form.lastname.value))
    {
        alert("Not a valid Last name format");
        return false;
    }
    if (!validPhoneNumber(form.phone.value))
    {
        alert("Invalid phone number format.\nTry ###-###-####");
        return false;
    }
    if (!validEmail(form.email.value))
    {
        alert("Invalid email format.\nTry something@domain.extension");
        return false;
    }
    if (!validShippingAddress(form.shippingAddress.value))
    {
        alert("Invalid Shipping Address format");
        return false;
    }
    if (!validZipCode(form.zipCode.value))
    {
        alert("Invalid Zip Code format.\nTry a number between 0 and 99999.");
        return false;
    }
    if (!validCity(form.city.value)) 
    {
        alert("Invalid city format.\nCity must not be blank and must contain only letters.");
        return false;
    }
    if (!validCreditCardNumber(form.creditCard.value))
    {
        alert("Not a valid credit card number format.\nValid credit cards contain only numbers with length greater than 10.");
        return false;
    }
    return true;
}

function validQuantity(quantity)
{
    return parseInt(quantity) > 0;
}

function validName(name)
{
    //not really sure how to validate a name
    var nameRegex = /^[a-zA-Z ]+$/;
    return name.length > 0 && name.match(nameRegex);
}

function validPhoneNumber(phoneNum)
{
    //matches ##########, ###-###-####, (###)###-####, ...
     var phoneRegex = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
     return phoneNum.match(phoneRegex);
}

function validEmail(email)
{
    var regex = /\S+@\S+\.\S+/;
    return email.match(regex);
}

function validShippingAddress(shippingAddress)
{
    //not sure how to validate a shipping address...
    return shippingAddress.length > 0;
}

function validZipCode(zipCode)
{
    var zipRegex = /^[0-9]+$/;
    return zipCode.match(zipRegex) && zipCode.toString().length > 0 && zipCode.toString().length <= 5;
}

function validCity(city)
{
    //not really sure how to validate a name
    var nameRegex = /^[a-zA-Z ]*$/;
    return city.length > 0 && city.match(nameRegex);
}

function validCreditCardNumber(creditCardNum)
{
    //there are many types of credit card formats, so let's
    //just check if it's a long number
    return creditCardNum.length > 10 && isJustNumbers(creditCardNum);
}

function isJustNumbers(num)
{
    //isNaN and parseInt are not sufficient....
   var regex = /^\d+$/;
   return num.match(regex);
}