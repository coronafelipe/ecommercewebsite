/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function autofillCityState(zip)
{
    var xhr;
    try {
	// Opera 8.0+, Firefox, Safari
	xhr = new XMLHttpRequest();
    } catch (e){
        // Internet Explorer Browsers
	try {
            xhr = new ActiveXObject("Msxml2.XMLHTTP");
	} catch (e) {
            try {
                xhr = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (e){
                // Something went wrong
                alert("Your browser is broken! :(");
                return false;
            }
        }
    }
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            var result = xhr.responseText;
            var cityState = result.split(',');
            if (cityState.length === 2) {
                if (document.getElementById("city").value === "") {
                    document.getElementById("city").value = cityState[0];
                }
                document.getElementById("state").value = cityState[1];   
            }
        }
    };
    xhr.open("POST", "../PHP_Helper/getCityState.php", true);
    xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
    xhr.send("zip=" + zip);
}


function calculatePrice(quantity, product_id) {
    var xhr;
    try {
	// Opera 8.0+, Firefox, Safari
	xhr = new XMLHttpRequest();
    } catch (e){
        // Internet Explorer Browsers
	try {
            xhr = new ActiveXObject("Msxml2.XMLHTTP");
	} catch (e) {
            try {
                xhr = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (e){
                // Something went wrong
                alert("Your browser is broken! :(");
                return false;
            }
        }
    }
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            var result = xhr.responseText;
            var tax = document.getElementById("tax").value;
            
            var num_price = parseFloat(result);    
            var num_tax = parseFloat(tax);
            var num_totaltax = num_tax * parseFloat(quantity);
            var num_shipping = 0;
            
            var shippingMethodArray = document.getElementsByName('shippingMethod');
            for (var i = 0; i < shippingMethodArray.length; i++) {
                if (shippingMethodArray[i].type === 'radio' && shippingMethodArray[i].checked) {
                    num_shipping = parseFloat(shippingMethodArray[i].value);
                    break;
                }
            }
            var totalPrice = parseFloat(num_shipping) + parseFloat(num_price) + parseFloat(num_totaltax);
            document.getElementById("tax").value = num_tax.toFixed(2);
            document.getElementById("totaltax").value = num_totaltax.toFixed(2);
            document.getElementById("form-product-tax").innerHTML = "Tax: $" + num_totaltax.toFixed(2);
            document.getElementById("price").value = num_price.toFixed(2);
            document.getElementById("form-product-price").innerHTML = "Price: $" + num_price.toFixed(2);
            document.getElementById("totalprice").value = totalPrice.toFixed(2);
            document.getElementById("form-product-totalprice").innerHTML = "Total Price: $" + totalPrice.toFixed(2);
        }
    };
    xhr.open("POST", "../PHP_Helper/calculatePrice.php", true);
    xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
    xhr.send("quantity=" + quantity + "&id=" + product_id);  
}


function calculateTax(zip, product_id) {
    var xhr;
    try {
	// Opera 8.0+, Firefox, Safari
	xhr = new XMLHttpRequest();
    } catch (e){
        // Internet Explorer Browsers
	try {
            xhr = new ActiveXObject("Msxml2.XMLHTTP");
	} catch (e) {
            try {
                xhr = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (e){
                // Something went wrong
                alert("Your browser is broken! :(");
                return false;
            }
        }
    }
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            var result = xhr.responseText;
            var tax = parseFloat(result);
            var totaltax = tax * parseFloat(document.getElementById("quantity").value);
            var currentPrice = parseFloat(document.getElementById("price").value);
            var currentShipping = 0;
            
            shippingMethodArray = document.getElementsByName('shippingMethod');
            for (var i = 0; i < shippingMethodArray.length; i++) {
                if (shippingMethodArray[i].type === 'radio' && shippingMethodArray[i].checked) {
                    currentShipping = shippingMethodArray[i].value;
                    break;
                }
            }
            
            var totalPrice = parseFloat(currentShipping) + parseFloat(currentPrice) + parseFloat(totaltax);
            document.getElementById("tax").value = parseFloat(tax).toFixed(2);
            document.getElementById("totaltax").value = parseFloat(totaltax).toFixed(2);
            document.getElementById("form-product-tax").innerHTML = "Tax: $" + parseFloat(totaltax).toFixed(2);
            document.getElementById("totalprice").value = parseFloat(totalPrice).toFixed(2);
            document.getElementById("form-product-totalprice").innerHTML = "Total Price: $" + parseFloat(totalPrice).toFixed(2);
        }
    };
    xhr.open("POST", "../PHP_Helper/calculateTax.php", true);
    xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
    xhr.send("zip=" + zip + "&id=" + product_id);  
}

function calculateShipping ()
{
    var shippingMethodArray = document.getElementsByName('shippingMethod');
    var currentPrice = document.getElementById("price").value;
    var currentTax = document.getElementById("totaltax").value;
    var shippingValue = 0;
    for (var i = 0; i < shippingMethodArray.length; i++) {
        if (shippingMethodArray[i].type === 'radio' && shippingMethodArray[i].checked) {
            shippingValue = shippingMethodArray[i].value;
            break;
        }
    }
    var totalPrice = parseFloat(shippingValue) + parseFloat(currentPrice) + parseFloat(currentTax);
    document.getElementById("totalprice").value = parseFloat(totalPrice).toFixed(2);
    document.getElementById("form-product-totalprice").innerHTML = "Total Price: $" + parseFloat(totalPrice).toFixed(2);
}