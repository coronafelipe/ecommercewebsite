window.onmouseout = function(event) {
    /* Close dropdown menu if user hovers outside of it */
    if (event.target.matches(".headerDropdown") || event.target.matches("#productDropdown")) {
        var dropdowns = document.getElementsByClassName("headerDropdown");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
            dropdowns[i].style.display = 'none';
        }
    }
};


window.onmouseover = function(event) {
    /* Open dropdown menu if user hovers over Products or 
    * anything below it */
    if (event.target.matches(".headerDropdown") || event.target.matches("#productDropdown")) {
        var dropdowns = document.getElementsByClassName("headerDropdown");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
            dropdowns[i].style.display = 'block';
        }
    }
    
    /* Changes sale main image to a mini-image you hovered over */
    if (event.target.matches(".sale-img")) {
        // Picture of mini-images where mouse is over
        var img = event.target.src;
        
        // Main image
        var main_image = document.getElementById("sale-product-img");
        main_image.src = img;
    }
};