<?php
$conn = new PDO('mysql:host=sylvester-mccoy-v3.ics.uci.edu; dbname=inf124grp29','inf124grp29', 'y2brExa+');
// See the "errors" folder for details...
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
