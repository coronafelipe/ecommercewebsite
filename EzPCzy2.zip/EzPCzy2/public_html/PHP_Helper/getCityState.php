<?php require_once "pdo.php";
$zipcode = filter_input(INPUT_POST, 'zip');
$sql1 = "SELECT city, state, zip from zip_codes where zip = '$zipcode'";

$city = NULL;
$state = NULL;

try {
    foreach($conn->query($sql1) as $cityState) {
        $city = $cityState['city'];
	$state = $cityState['state'];
    }
} catch (Exception $ex) {
//    echo $ex->getMessage();
}

if (isset($city) && isset($state)) {
    $return_value = $city . "," . $state;
    print $return_value;
}

?>