<?php
require_once "pdo.php";

$zip = filter_input(INPUT_POST, "zip");
$product_id = filter_input(INPUT_POST, "id");
$sql = "SELECT price FROM products WHERE id=" . $product_id;
$sql2 = "SELECT tax_rate FROM tax_rates WHERE zipcode=" . $zip;

try {
    foreach($conn->query($sql) as $product) {
        foreach($conn->query($sql2) as $tax_rates) {
            $price = $product['price'];
            $tax_rate = $tax_rates['tax_rate'];
            $tax = $price * $tax_rate;
            print $tax;
            return;
        }
        print 0;
    }
} catch (Exception $ex) {
//    echo $ex->getMessage();
}