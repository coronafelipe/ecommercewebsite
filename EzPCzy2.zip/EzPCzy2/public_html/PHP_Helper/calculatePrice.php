<?php
require_once "pdo.php";

$quantity = filter_input(INPUT_POST, "quantity");
$product_id = filter_input(INPUT_POST, "id");

$sql = "SELECT price FROM products WHERE id=" . $product_id;

try {
    foreach($conn->query($sql) as $product) {
        $price = $product['price'];
        $totalprice = bcmul($price, $quantity, 2);
        print $totalprice;
    }
} catch (Exception $ex) {
//    echo $ex->getMessage();
}

