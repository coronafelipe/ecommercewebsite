<?php 
require_once "PHP_Helper/pdo.php"; 

function goBack() {
    echo "<script>window.history.back();</script>";
}

function invalidInput($message) {
    echo "<script>alert('" . $message . "'); window.history.back();</script>";
}

function hideCreditCardInfo($credCard) {
    $result = "";
    for ($i = 0; $i < strlen($credCard); $i++) {
        if (strlen($credCard)-$i <= 4) {
            $result = (string)$result . (string)$credCard{$i};
        } else {
            $result = (string)$result . "x";
        }
    }
    return $result;
}

/* DO CHECKING FOR FORM SUBMISSION HERE!!
 * 
 * IF the user input is invalid, use method history_back to go back a page
 * http://www.w3schools.com/jsref/met_his_back.asp
 *      - Probably do nothing if someone try to directly access this page 
 *          without data
 *      - Probably alert user with something if invalid data
 * 
 * IF user input is valid, add it to the DB and then continue below
 */
function isValidID($id, $conn)
{
    $sql = "SELECT id FROM products WHERE id=" . $id;
    foreach($conn->query($sql) as $product) {
        return (int)$product['id'] == (int)$id;
    }
    return false;
}

function isPosInt($num)
{
    return (int)$num == $num && (int)$num > 0;
}

function isPosDouble($num)
{
    return (double)$num == $num && (double)$num >= 0;
}

function isValidName($name)
{
    return strcspn($name, '0123456789') == strlen($name);
}

function isValidPhone($phone)
{
    //dunno if this works
    return preg_match('/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/', $phone);
}

function isValidEmail($email)
{
    return preg_match('/\S+@\S+\.\S+/', $email);
}

function isValidShippingAddress($shippingAddress)
{
    return !empty($shippingAddress);
}

function isValidZipCode($zipCode, $conn)
{
    $sql1 = "SELECT zipcode FROM tax_rates WHERE zipcode=" . $zipCode;
    $sql2 = "SELECT zip FROM zip_codes WHERE zip=" . $zipCode;
    foreach($conn->query($sql1) as $zip) {
        return true;
    }
    foreach($conn->query($sql2) as $zip) {
        return true;
    }
    return false;
}

function isValidCity($city)
{
    return preg_match('/^[a-zA-Z ]+$/', $city);
}

function isValidState($state, $conn)
{
    $sql = "SELECT DISTINCT state FROM zip_codes WHERE state='" . $state . "';";
    foreach($conn->query($sql) as $state_result) {
        return $state_result['state'] == $state;
    }
    return false;
}

function isValidCreditCard($creditCard)
{
    return strlen($creditCard) > 10 && isPosInt($creditCard);
}

function isValidShippingMethod($shippingMethod)
{
    return strcmp($shippingMethod, '0') || // 6-days ground (Free)
            strcmp($shippingMethod, '4.99') || // 2-days Expedited ($4.99)
            strcmp($shippingMethod, '9.99'); // Overnight ($9.99)
}
/*
id
quantity
firstname
lastname
phone
email
shippingAddress
zipCode
city
state
creditCard
shippingMethod
price
totalprice
totaltax
 */


// BEGIN CODE HERE
if (filter_input(INPUT_SERVER, "REQUEST_METHOD") == "POST")
{
    // Variables that get check
    $id = filter_input(INPUT_POST, 'id');
    $quantity = filter_input(INPUT_POST, 'quantity');
    $firstname = filter_input(INPUT_POST, 'firstname');
    $lastname = filter_input(INPUT_POST, 'lastname');
    $phone = filter_input(INPUT_POST, 'phone');
    $email = filter_input(INPUT_POST, 'email');
    $shippingAddress = filter_input(INPUT_POST, 'shippingAddress');
    $zipCode = filter_input(INPUT_POST, 'zipCode');
    $city = filter_input(INPUT_POST, 'city');
    $state = filter_input(INPUT_POST, 'state');
    $creditCard = filter_input(INPUT_POST, 'creditCard');
    $shippingMethod = filter_input(INPUT_POST, 'shippingMethod');
    $price = filter_input(INPUT_POST, 'price');
    $totalprice = filter_input(INPUT_POST, 'totalprice');
    $totaltax = filter_input(INPUT_POST, 'totaltax');

    // Variables that doesn't need checking (except for NULLs)
    $title = filter_input(INPUT_POST, 'title');
    
    // Variables that doesn't need any checking
    $primary_pic = filter_input(INPUT_POST, 'primary_pic');

    if (!isset($id) || !isValidID($id, $conn)) 
    {
        invalidInput("Invalid product ID");
    }
    if (!isset($quantity) || !isPosInt($quantity))
    {
        invalidInput('Invalid quantity');
    }
    if (empty($firstname) || !isValidName($firstname))
    {
        invalidInput('Invalid firstname');
    }
    if (empty($lastname) || !isValidName($firstname))
    {
        invalidInput('Invalid lastname');
    }
    if (!isset($phone) || !isValidPhone($phone))
    {
        invalidInput('Invalid phone');
    }
    if (empty($email) || !isValidEmail($email))
    {
        invalidInput('Invalid email');
    }
    if (empty($shippingAddress) || !isValidShippingAddress($shippingAddress))
    {
        invalidInput('Invalid shippingAddress');
    }
    if (empty($zipCode) || !isValidZipCode($zipCode, $conn))
    {
        invalidInput('Invalid zipCode');
    }
    if (empty($city) || !isValidCity($city))
    {
        invalidInput('Invalid city');
    }
    if (empty($state) || !isValidState($state, $conn))
    {
        invalidInput('Invalid state');
    }
    if (!isset($creditCard) || !isValidCreditCard($creditCard))
    {
        invalidInput('Invalid creditCard');
    }
    if (!isset($shippingMethod) || !isValidShippingMethod($shippingMethod))
    {
        invalidInput('Invalid shippingMethod');
    }
    if (!isset($price) || !isPosDouble($price)) 
    {
        invalidInput('Invalid price');
    }
    if (!isset($totalprice) || !isPosDouble($totalprice)) 
    {
        invalidInput('Invalid total price');
    }
    if (!isset($totaltax) || !isPosDouble($totaltax))
    {
        invalidInput('Invalid total tax');
    }
    if (empty($title))
    {
        invalidInput("Item does not exist");
    }
    
    //after trying to validate
    $stmt = $conn->prepare("INSERT INTO orders (product_title, product_picture, price, tax, total_price, quantity, first_name, last_name, phone_number, email, address, zipcode, city, state, creditcard, shipping) 
                            VALUES (:product_title, :product_picture, :price, :tax, :total_price, :quantity, :first_name, :last_name, :phone_number, :email, :address, :zipcode, :city, :state, :creditcard, :shipping)");
    $stmt->bindParam(':product_title', $title);
    $stmt->bindParam(':product_picture', $primary_pic);
    $stmt->bindParam(':price', $price);
    $stmt->bindParam(':tax', $totaltax);
    $stmt->bindParam(':total_price', $totalprice);
    $stmt->bindParam(':quantity', $quantity); 
    $stmt->bindParam(':first_name', $firstname);
    $stmt->bindParam(':last_name', $lastname);
    $stmt->bindParam(':phone_number', $phone);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':address', $shippingAddress);
    $stmt->bindParam(':zipcode', $zipCode);
    $stmt->bindParam(':city', $city);
    $stmt->bindParam(':state', $state);
    $stmt->bindParam(':creditcard', $creditCard);
    $stmt->bindParam(':shipping', $shippingMethod);
    $stmt->execute();
}
else 
{
    goBack();
}

?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>EzPCzy</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="CSS/master.css" type="text/css">
        <link rel="stylesheet" href="CSS/form.css" type="text/css">
        <link rel="stylesheet" href="CSS/sales.css" type="text/css">
        <script language="javascript" type="text/javascript" src="JS/eventhandlers.js"></script>
        <script language="javascript" type="text/javascript" src="JS/order-form-validation.js"></script>
    </head>
    <body>
        <header>
            <h2>EzPCzy</h2>
            <hr>
            <img src="images/logo.png" alt="EzPCzy"/>
            <nav>
                <a href="index.php">Home</a>
                <a href="products.php?products=Products" id="productDropdown">Products</a>
                <a href="about.html">About</a>
                <a href="theteam.html">The Team</a>
                <a href="contactus.html">Contact Us</a>
                <table id="headerNavDropdown" cellspacing="0" cellpadding="0">
                    <tr>
                        <td></td>
                        <td><a href="products.php?products=Laptops" class="headerDropdown">Laptops</a></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><a href="products.php?products=Desktops" class="headerDropdown">Desktops</a></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><a href="products.php?products=Accessories" class="headerDropdown">Accessories</a></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>               
                </table>
            </nav>
        </header>
        <div class="container">
            <center>
                <h1>Order Confirm!</h1>
                <div class ="sale">
            <?php
                //print("<p>Order confirmed! ProductID:".$id." Quantity: ".$quantity);
                print("<h2>". $title ."</h2>");
                print("<img width='320' height='240' src='" . $primary_pic . "' alt='" . $title . "'/><br/><br/>");
                print("<h4>Product ID: " . $id . "</h4>");
            ?>
                </div>
                <table id='form-price-submit'>
                    <?php
                        print("<tr>");
                        print("<td><h3>Price: $" . $price . "</h3></td>");
                        print("<td><h3>Tax: $" . $totaltax . "</h3></td>");
                        print("<td><h3>Shipping: $" . number_format((double)$shippingMethod, 2, '.', '') . "</h3></td>");
                        print("<td><h3>Total Price: $" . $totalprice . "</h3></td>");
                        print("</tr>");
                    ?>
                </table><br/>
                <?php
                    print("<table>");
                    print("<tr><td class='form-submit-info'><p>Quantity: </p></td>");
                    print("<td class='form-submit-result'>" . $quantity . "</td></tr>");
                    echo "<tr><td><br></td><td><br></td></tr>";
                    print("<tr><td class='form-submit-info'><p>First Name: </p></td>");
                    print("<td class='form-submit-result'>" . $firstname . "</td></tr>");
                    print("<tr><td class='form-submit-info'><p>Last Name: </p></td>");
                    print("<td class='form-submit-result'>" . $lastname . "</td></tr>");
                    print("<tr><td class='form-submit-info'><p>Phone Number: </p></td>");
                    print("<td class='form-submit-result'>" . $phone . "</td></tr>");
                    print("<tr><td class='form-submit-info'><p>Email Address: </p></td>");
                    print("<td class='form-submit-result'>" . $email . "</td></tr>");
                    echo "<tr><td><br></td><td><br></td></tr>";
                    print("<tr><td class='form-submit-info'><p>Shipping Address: </p></td>");
                    print("<td class='form-submit-result'>" . $shippingAddress . "</td></tr>");
                    print("<tr><td class='form-submit-info'><p>Zip Code: </p></td>");
                    print("<td class='form-submit-result'>" . $zipCode . "</td></tr>");
                    print("<tr><td class='form-submit-info'><p>City: </p></td>");
                    print("<td class='form-submit-result'>" . $city . "</td></tr>");
                    print("<tr><td class='form-submit-info'><p>State: </p></td>");
                    print("<td class='form-submit-result'>" . $state . "</td></tr>");
                    echo "<tr><td><br></td><td><br></td></tr>";
                    print("<tr><td class='form-submit-info'><p>Credit Card Number: </p></td>");
                    print("<td class='form-submit-result'>" . hideCreditCardInfo($creditCard) . "</td></tr>");
                    print("</table>");
                ?>
            </center>
            <br/><br/><br/><br/>
        </div>
        <footer>
            <p>© 2016 CS 137 Group 29, Inc.</p>
            <nav>
                <a href="privacy-policy.html">Privacy Policy</a>
                <a href="terms-and-conditions.html">Terms and Conditions</a>
            </nav>
        </footer>
    </body>
</html>
