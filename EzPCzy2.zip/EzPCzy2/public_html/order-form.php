<?php require_once "PHP_Helper/pdo.php"; ?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>EzPCzy</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="CSS/master.css" type="text/css">
        <link rel="stylesheet" href="CSS/form.css" type="text/css">
        <script language="javascript" type="text/javascript" src="JS/eventhandlers.js"></script>
        <script language="javascript" type="text/javascript" src="JS/order-form-validation.js"></script>
        <script language="javascript" type="text/javascript" src="JS/order-form-ajax.js"></script>
    </head>
    <body>
        <header>
            <h2>EzPCzy</h2>
            <hr>
            <img src="images/logo.png" alt="EzPCzy"/>
            <nav>
                <a href="index.php">Home</a>
                <a href="products.php?products=Products" id="productDropdown">Products</a>
                <a href="about.html">About</a>
                <a href="theteam.html">The Team</a>
                <a href="contactus.html">Contact Us</a>
                <table id="headerNavDropdown" cellspacing="0" cellpadding="0">
                    <tr>
                        <td></td>
                        <td><a href="products.php?products=Laptops" class="headerDropdown">Laptops</a></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><a href="products.php?products=Desktops" class="headerDropdown">Desktops</a></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><a href="products.php?products=Accessories" class="headerDropdown">Accessories</a></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>               
                </table>
            </nav>
        </header>
        <div class="container">
            <?php
            try {
                $product_available = FALSE;
                $idParameter = htmlspecialchars($_GET['id']);

                if (filter_var($idParameter, FILTER_VALIDATE_INT)) {
                    $sql1 = "SELECT title, primary_pic, id, price FROM products WHERE id=" . $idParameter;
                    $sql_state = "SELECT DISTINCT state FROM zip_codes ORDER BY state ASC;";
                    foreach($conn->query($sql1) as $product) {
                        $product_available = TRUE;
                        echo "<form action='order-form-submit.php' method='post' autocomplete='off' onsubmit='return submitOrderForm(this)'>";
                        echo "<h1>Order Product</h1>";
                        echo "<div class='sale'>";
                        echo "<h2>" . $product['title'] . "</h2>";
                        echo "<img id='sale-product-img' width='320' height='240' src='" . $product['primary_pic'] . "' alt='" . $product['title'] . "'/><br/>";
                        echo "<h4>Product ID: " . $product['id'] . "</h4></div></table>";
                        echo "<input type='hidden' name='primary_pic' value='" . $product['primary_pic'] . "'>";
                        echo "<input type='hidden' name='title' value='" . $product['title'] . "'>";
                        echo "<input type='hidden' id='form-product-id' name='id' value='" . $product['id'] . "'>";
                        
                        echo "<input type='hidden' id='price' name='price' value='" . $product['price'] . "'>";
                        echo "<input type='hidden' id='tax' name='tax' value='0'>";
                        echo "<input type='hidden' id='totaltax' name='totaltax' value='0'>";
                        echo "<input type='hidden' id='totalprice' name='totalprice' value='" . $product['price'] . "'>";
                        echo "<table id='form-price'><tr>";
                        echo "<td><h3 id='form-product-price'>Price: $" . $product['price'] . "</h3></td>";
                        echo "<td><h3 id='form-product-tax'>Tax: $0.00</h3></td>";
                        echo "<td><h3 id='form-product-totalprice'>Total Price: $" . $product['price'] . "</h3></td>";
                        echo "</tr></table><br/>";
                        
                        echo "<table>";
                        echo "<tr><td><p>Quantity:</p></td>";
                        echo "<td class='form-input'><input type='number' min='1' step='1' value='1' name='quantity' id='quantity' onblur=\"calculatePrice(this.value,'" . $product['id'] . "')\"></td></tr>";
                        echo "<tr><td><br></td><td><br></td></tr>";
                        
                        echo "<tr><td><p>First Name:</p></td>";
                        echo "<td class='form-input'><input type='text' name='firstname'></td></tr>";
                        echo "<tr><td><p>Last Name:</p></td>";
                        echo "<td class='form-input'><input type='text' name='lastname'></td></tr>";
                        echo "<tr><td><p>Phone Number:</p></td>";
                        echo "<td class='form-input'><input type='text' name='phone'></td></tr>";
                        echo "<tr><td><p>Email Address:</p></td>";
                        echo "<td class='form-input'><input type='text' name='email'></td></tr>";
                        echo "<tr><td><br></td><td><br></td></tr>";
                        
                        echo "<tr><td><p>Shipping Address: </p></td>";
                        echo "<td class='form-input'><input type='text' name='shippingAddress'></td></tr>";
                        echo "<tr><td><p>Zip Code: </p></td>";
                        echo "<td class='form-input'><input id='zipCode' type='number' name='zipCode' onblur=\"autofillCityState(this.value); calculateTax(this.value,'" . $product['id'] . "');\" min='0' max='99999'></td></tr>";
                        echo "<tr><td><p>City: </p></td>";
                        echo "<td class='form-input'><input id='city' type='text' name='city'></td></tr>";
                        echo "<tr><td><p>State: </p></td>";
                        echo "<td class='form-input'><select id='state' name='state'>";
                        foreach($conn->query($sql_state) as $states) {
                            echo "<option value='" . $states['state'] . "'>" . $states['state'] . "</option>";
                        }
                        echo "</select></td></tr>";
                        echo "<tr><td><br></td><td><br></td></tr>";
                        
                        echo "<tr><td><p>Credit Card Number: </p></td>";
                        echo "<td class='form-input'><input type='text' name='creditCard'></td></tr>";
                        echo "<tr><td><p>Shipping Method: </p></td>";
                        echo "<td class='form-input'>";
                        echo '<input type="radio" class="shippingMethod" name="shippingMethod" value="0" onchange="calculateShipping()" checked> 6-days ground (Free)<br>';
                        echo '<input type="radio" class="shippingMethod" name="shippingMethod" value="4.99" onchange="calculateShipping()" > 2-days Expedited ($4.99)<br>';
                        echo '<input type="radio" class="shippingMethod" name="shippingMethod" value="9.99" onchange="calculateShipping()"> Overnight ($9.99)';
                        echo "</td></tr></table><br/><br/>";
                        echo '<input type="submit" name="submit" value="Submit"></form>';
                    }
                }
                if (!$product_available) {
                    echo "<CENTER>";
                    echo "<h1>WE'RE SORRY!</h1>";
                    echo "<h2>The following item you were looking for does not exist.</h2>";
                    echo "<h2>Please try again.</h2>";
                    echo "<img src='images/sadface.png' width='420' height='420'/>";   
                    echo "</CENTER>";
                }
            } catch (Exception $ex) {
//                echo $ex->getMessage();
            }
            ?>
            <br/><br/><br/><br/><br/>
        </div>
        <footer>
            <p>© 2016 CS 137 Group 29, Inc.</p>
            <nav>
                <a href="privacy-policy.html">Privacy Policy</a>
                <a href="terms-and-conditions.html">Terms and Conditions</a>
            </nav>
        </footer>
    </body>
</html>
