<?php require_once "PHP_Helper/pdo.php"; ?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>EzPCzy</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="CSS/master.css" type="text/css">
        <link rel="stylesheet" href="CSS/sales.css" type="text/css">
        <script language="javascript" type="text/javascript" src="JS/eventhandlers.js"></script>        
    </head>
    <body>
        <header>
            <h2>EzPCzy</h2>
            <hr>
            <img src="images/logo.png" alt="EzPCzy"/>
            <nav>
                <a href="index.php">Home</a>
                <a href="products.php?products=Products" id="productDropdown">Products</a>
                <a href="about.html">About</a>
                <a href="theteam.html">The Team</a>
                <a href="contactus.html">Contact Us</a>
                <table id="headerNavDropdown" cellspacing="0" cellpadding="0">
                    <tr>
                        <td></td>
                        <td><a href="products.php?products=Laptops" class="headerDropdown">Laptops</a></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><a href="products.php?products=Desktops" class="headerDropdown">Desktops</a></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><a href="products.php?products=Accessories" class="headerDropdown">Accessories</a></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>               
                </table>
            </nav>
        </header>
        <div class="container">
            <div class="sale">
                <?php
                    try {
                        $product_available = FALSE;
                        $idParameter = htmlspecialchars($_GET['id']);
                        
                        if (filter_var($idParameter, FILTER_VALIDATE_INT)) {
                            $sql1 = "SELECT * FROM products WHERE id=" . $idParameter;
                            $sql2 = "SELECT description FROM descriptions WHERE id=" . $idParameter;
                            $sql3 = "UPDATE products SET clicks = clicks + 1 WHERE id=" . $idParameter;
                            foreach($conn->query($sql1) as $product) {
                                $product_available = TRUE;
                                echo "<h1>" . $product['title'] . "</h1>";
                                echo "<img id='sale-product-img' src='" . $product['primary_pic'] . "' alt='" . $product['title'] . "'/><br/>";
                                echo "<a href='order-form.php?id=" . htmlspecialchars($_GET['id']) . "'>";
                                echo "<img id='buy-button' src='images/buy.png' alt='BUY NOW'/></a>";
                                echo "<h2>$" . $product['price'] . "</h2>";
                                echo "<div class='sales-item'>";
                                echo "<table><tr><td class='sales-item-key'>Product ID</td>";
                                echo "<td class='sales-item-value'>" . $product['id'] . "</td></tr></table><br/>";
                                echo "<table>";
                                echo "<tr><td class='sales-item-key'>Type</td>";
                                echo "<td class='sales-item-value'>" . $product['type'] . "</td></tr>";
                                echo "<tr><td class='sales-item-key'>Brand</td>";
                                echo "<td class='sales-item-value'>" . $product['brand'] . "</td></tr>";
                                echo "<tr><td class='sales-item-key'>Specs</td>";
                                echo "<td class='sales-item-value'><ul>";
                                foreach($conn->query($sql2) as $description) {
                                    echo "<li>" . $description['description'] . "</li>";
                                }
                                echo "</ul></td></tr></table><br/><br/>";
                                echo "<table id='sale-imgs'><tr>";
                                echo "<td><img class='sale-img' src='" . $product['primary_pic'] . "' alt='sale item'/></td>";
                                echo "<td><img class='sale-img' src='" . $product['pic1'] . "' alt='sale item'/></td>";
                                echo "<td><img class='sale-img' src='" . $product['pic2'] . "' alt='sale item'/></td>";
                                echo "<td><img class='sale-img' src='" . $product['pic3'] . "' alt='sale item'/></td>";
                                echo "<td><img class='sale-img' src='" . $product['pic4'] . "' alt='sale item'/></td>";
                                echo "</tr></table></div>";
                                // UPDATE click counts for hot items
                                $conn->query($sql3);
                            }
                        }
                        if (!$product_available) {
                                echo "<h1>WE'RE SORRY!</h1>";
                                echo "<h2>The following item you were looking for does not exist.</h2>";
                                echo "<h2>Please try again.</h2>";
                                echo "<img src='images/sadface.png' width='420' height='420'/>";   
                        }
                    } catch (Exception $ex) {
//                        echo $ex->getMessage();
                    }
                ?>
                    
            </div>
            <br/><br/><br/>
        </div>
        <footer>
            <p>© 2016 CS 137 Group 29, Inc.</p>
            <nav>
                <a href="privacy-policy.html">Privacy Policy</a>
                <a href="terms-and-conditions.html">Terms and Conditions</a>
            </nav>
        </footer>
    </body>
</html>
