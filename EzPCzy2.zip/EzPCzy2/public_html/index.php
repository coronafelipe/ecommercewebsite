<?php require_once "PHP_Helper/pdo.php"; ?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>EzPCzy</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="CSS/master.css" type="text/css">
        <link rel="stylesheet" href="CSS/sales.css" type="text/css">
        <script language="javascript" type="text/javascript" src="JS/eventhandlers.js"></script>
    </head>
    <body>
        <header>
            <h2>EzPCzy</h2>
            <hr>
            <img src="images/logo.png" alt="EzPCzy"/>
            <nav>
                <a href="index.php">Home</a>
                <a href="products.php?products=Products" id="productDropdown">Products</a>
                <a href="about.html">About</a>
                <a href="theteam.html">The Team</a>
                <a href="contactus.html">Contact Us</a>
                <table id="headerNavDropdown" cellspacing="0" cellpadding="0">
                    <tr>
                        <td></td>
                        <td><a href="products.php?products=Laptops" class="headerDropdown">Laptops</a></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><a href="products.php?products=Desktops" class="headerDropdown">Desktops</a></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><a href="products.php?products=Accessories" class="headerDropdown">Accessories</a></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>               
                </table>
            </nav>
        </header>
        <div class="container">
            <h1>Newest Items</h1>
            <table class="sales-list">
                <!-- Title of Items on Sale -->
                <?php
                    try {
                        $sql1 = "SELECT title FROM products ORDER BY id DESC LIMIT 3;";
                        echo "<tr>";
                        foreach($conn->query($sql1) as $product) {
                            echo "<td><h2>" . $product['title'] . "</h2></td>";
                        }
                        echo "</tr>";
                        $sql2 = "SELECT id, primary_pic, title FROM products ORDER BY id DESC LIMIT 3;";
                        echo "<tr>";
                        foreach($conn->query($sql2) as $product) {
                            echo "<td><a href='product.php?id=" . $product['id'] . "'>";
                            echo "<img src='" . $product['primary_pic'] . "' alt='" . $product['title'] . "'/>";
                            echo "</a></td>";
                        }
                        echo "</tr>";
                        $sql3 = "SELECT * FROM products ORDER BY id DESC LIMIT 3;";
                        echo "<tr>";
                        foreach($conn->query($sql3) as $product) {
                            echo "<td><div class='sales-item'><table>";
                            echo "<tr><td class='sales-item-key'>Type</td>";
                            echo "<td class='sales-item-value'>" . $product['type'] . "</td></tr>";
                            echo "<tr><td class='sales-item-key'>Brand</td>";
                            echo "<td class='sales-item-value'>" . $product['brand'] . "</td></tr>";
                            echo "<tr><td class='sales-item-key'>Specs</td>";
                            echo "<td class='sales-item-value'><ul>";
                            $sql3_1 = "SELECT description FROM descriptions WHERE main_spec='TRUE' AND id='" . $product['id'] . "';";
                            foreach($conn->query($sql3_1) as $descriptions) {
                                echo "<li>" . $descriptions['description'] . "</li>";
                            }
                            echo "</ul></td></tr></table></div></td>";
                        }
                        echo "</tr>";
                        $sql4 = "SELECT price FROM products ORDER BY id DESC LIMIT 3;";
                        echo "<tr>";
                        foreach($conn->query($sql4) as $product) {
                            echo "<td><h3>$" . $product['price'] . "</h3></td>";
                        }
                        echo "</tr>";
                    } catch (Exception $ex) {
                    } 
                ?>
            </table>
            <br/><br/>
            <h1>Hottest Items</h1>
            <table class="sales-list">
                <?php
                    try {
                        $sql1a = "SELECT title FROM products ORDER BY clicks DESC LIMIT 3;";
                        echo "<tr>";
                        foreach($conn->query($sql1a) as $product) {
                            echo "<td><h2>" . $product['title'] . "</h2></td>";
                        }
                        echo "</tr>";
                        $sql2b = "SELECT id, primary_pic, title FROM products ORDER BY clicks DESC LIMIT 3;";
                        echo "<tr>";
                        foreach($conn->query($sql2b) as $product) {
                            echo "<td><a href='product.php?id=" . $product['id'] . "'>";
                            echo "<img src='" . $product['primary_pic'] . "' alt='" . $product['title'] . "'/>";
                            echo "</a></td>";
                        }
                        echo "</tr>";
                        $sql3c = "SELECT * FROM products ORDER BY clicks DESC LIMIT 3;";
                        echo "<tr>";
                        foreach($conn->query($sql3c) as $product) {
                            echo "<td><div class='sales-item'><table>";
                            echo "<tr><td class='sales-item-key'>Type</td>";
                            echo "<td class='sales-item-value'>" . $product['type'] . "</td></tr>";
                            echo "<tr><td class='sales-item-key'>Brand</td>";
                            echo "<td class='sales-item-value'>" . $product['brand'] . "</td></tr>";
                            echo "<tr><td class='sales-item-key'>Specs</td>";
                            echo "<td class='sales-item-value'><ul>";
                            $sql3_1 = "SELECT description FROM descriptions WHERE main_spec='TRUE' AND id='" . $product['id'] . "';";
                            foreach($conn->query($sql3_1) as $descriptions) {
                                echo "<li>" . $descriptions['description'] . "</li>";
                            }
                            echo "</ul></td></tr></table></div></td>";
                        }
                        echo "</tr>";
                        $sql4a = "SELECT price FROM products ORDER BY clicks DESC LIMIT 3;";
                        echo "<tr>";
                        foreach($conn->query($sql4a) as $product) {
                            echo "<td><h3>$" . $product['price'] . "</h3></td>";
                        }
                        echo "</tr>";
                    } catch (Exception $ex) {
                        echo $ex->getMessage();
                    } 
                ?>
            </table>
            <br/><br/><br/><br/>
        </div>
        <footer>
            <p>© 2016 CS 137 Group 29, Inc.</p>
            <nav>
                <a href="privacy-policy.html">Privacy Policy</a>
                <a href="terms-and-conditions.html">Terms and Conditions</a>
            </nav>
        </footer>
    </body>
</html>
