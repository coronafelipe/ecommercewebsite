<?php 
    require_once "PHP_Helper/pdo.php"; 
    
    function fillEmptyColumn($current_col, $max_col) {
        if ($current_col < $max_col) {
            $col_to_fill = $max_col - $current_col;
            for ($x = 0; $x < $col_to_fill; $x++) {
                echo "<td></td>";
            }
        }
    }
?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>EzPCzy</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="CSS/master.css" type="text/css">
        <link rel="stylesheet" href="CSS/sales.css" type="text/css">
        <script language="javascript" type="text/javascript" src="JS/eventhandlers.js"></script>
    </head>
    <body>
        <header>
            <h2>EzPCzy</h2>
            <hr>
            <img src="images/logo.png" alt="EzPCzy"/>
            <nav>
                <a href="index.php">Home</a>
                <a href="products.php?products=Products" id="productDropdown">Products</a>
                <a href="about.html">About</a>
                <a href="theteam.html">The Team</a>
                <a href="contactus.html">Contact Us</a>
                <table id="headerNavDropdown" cellspacing="0" cellpadding="0">
                    <tr>
                        <td></td>
                        <td><a href="products.php?products=Laptops" class="headerDropdown">Laptops</a></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><a href="products.php?products=Desktops" class="headerDropdown">Desktops</a></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><a href="products.php?products=Accessories" class="headerDropdown">Accessories</a></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>               
                </table>
            </nav>
        </header>
        <div class="container">
            <?php 
                try {
                    $sale_header = "";
                    $where_filter = "";
                    $sales_array = array();
                    foreach($conn->query("SELECT DISTINCT type FROM products") as $types) {
                        $sales_array[] = $types['type'];
                    }
                    
                    // Filter for Products Type. If not in the list, show all products
                    $products_filter = htmlspecialchars($_GET['products']); 
                    if (in_array($products_filter, $sales_array)) {
                        $sale_header = $products_filter;
                        $where_filter = "WHERE type='" . $products_filter . "'";
                    } else {
                        $sale_header = "Products";
                        $where_filter = "WHERE 1=1";
                    }
                    
                    // Title of What Products Are On Sale
                    echo "<h1>All " . $sale_header . "</h1>";

                    // Product Counters
                    $max_products_count = 0;
                    $counter = 0;
                    
                    $sql_count_products = "SELECT id FROM products " . $where_filter;
                    foreach($conn->query($sql_count_products) as $count) {
                        $max_products_count++;
                    }

                    // BEGIN Populating Data
                    $col_counter = 3;
                    $col_per_row = 3;
                    while ($counter < $max_products_count) {
                        $current_count = $counter;
                        // creates new sales list to make 3 columns per row
                        if ($col_counter >= $col_per_row) {
                            $col_counter = 0;
                            echo "<table class='sales-list'>";
                        }

                        $sql1 = "SELECT title FROM products " . $where_filter . " ORDER by id DESC LIMIT " . $current_count . ",3;";
                        echo "<tr>";
                        foreach($conn->query($sql1) as $product) {
                            echo "<td><h2>" . $product['title'] . "</h2></td>";
                            $counter++;
                            $col_counter++;
                        }
                        fillEmptyColumn($col_counter, $col_per_row);
                        echo "</tr>";

                        $sql2 = "SELECT id, primary_pic, title FROM products " . $where_filter . " ORDER BY id DESC LIMIT " . $current_count . ",3;";
                        echo "<tr>";
                        foreach($conn->query($sql2) as $product) {
                            echo "<td><a href='product.php?id=" . $product['id'] . "'>";
                            echo "<img src='" . $product['primary_pic'] . "' alt='" . $product['title'] . "'/>";
                            echo "</a></td>";
                        }
                        fillEmptyColumn($col_counter, $col_per_row);
                        echo "</tr>";

                        $sql3 = "SELECT * FROM products " . $where_filter . " ORDER BY id DESC LIMIT " . $current_count . ",3;";
                        echo "<tr>";
                        foreach($conn->query($sql3) as $product) {
                            echo "<td><div class='sales-item'><table>";
                            echo "<tr><td class='sales-item-key'>Type</td>";
                            echo "<td class='sales-item-value'>" . $product['type'] . "</td></tr>";
                            echo "<tr><td class='sales-item-key'>Brand</td>";
                            echo "<td class='sales-item-value'>" . $product['brand'] . "</td></tr>";
                            echo "<tr><td class='sales-item-key'>Specs</td>";
                            echo "<td class='sales-item-value'><ul>";
                            $sql3_1 = "SELECT description FROM descriptions WHERE main_spec='TRUE' AND id='" . $product['id'] . "';";
                            foreach($conn->query($sql3_1) as $descriptions) {
                                echo "<li>" . $descriptions['description'] . "</li>";
                            }
                            echo "</ul></td></tr></table></div></td>";
                        }
                        fillEmptyColumn($col_counter, $col_per_row);
                        echo "</tr>";

                        $sql4 = "SELECT price FROM products " . $where_filter . " ORDER BY id DESC LIMIT " . $current_count . ",3;";
                        echo "<tr>";
                        foreach($conn->query($sql4) as $product) {
                            echo "<td><h3>$" . $product['price'] . "</h3></td>";
                        }
                        fillEmptyColumn($col_counter, $col_per_row);
                        echo "</tr>";

                        // closes sales list when 3 columns are made
                        if ($col_counter >= $col_per_row) {
                            echo "</table><br/><br/><br/>";
                        }
                    }
                } catch (Exception $ex) {
//                    echo $ex->getMessage();
                }
            ?>
            <br/>
        </div>
        <footer>
            <p>© 2016 CS 137 Group 29, Inc.</p>
            <nav>
                <a href="privacy-policy.html">Privacy Policy</a>
                <a href="terms-and-conditions.html">Terms and Conditions</a>
            </nav>
        </footer>
    </body>
</html>
