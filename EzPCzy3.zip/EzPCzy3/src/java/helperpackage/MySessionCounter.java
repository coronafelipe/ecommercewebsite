package helperpackage;

import java.util.*;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 *
 * @author Felipe Corona
 */
public class MySessionCounter implements HttpSessionListener {
    @Override
    public void sessionCreated(HttpSessionEvent se) {
        HttpSession session = se.getSession();
        ServletContext ctx = session.getServletContext();
        String userID = session.getId();
        HashMap<String, HashSet<Integer>> session_list = (HashMap<String,HashSet<Integer>>)ctx.getAttribute("session_list");
        
        session_list.put(userID, new HashSet<Integer>());
        ctx.setAttribute("session_list", session_list);
    }

    @Override
    public void sessionDestroyed(HttpSessionEvent se) {
        HttpSession session = se.getSession();
        ServletContext ctx = session.getServletContext();
        String userID = session.getId();
        HashMap<String, HashSet<Integer>> session_list = (HashMap<String,HashSet<Integer>>)ctx.getAttribute("session_list");
        session_list.remove(userID);
        ctx.setAttribute("session_list", session_list);
    }
}