/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helperpackage;

import java.io.PrintWriter;
/**
 *
 * @author Felipe Corona
 */
public class Func_NotAvailable {
    
    // Displays a sad smiley telling you that your product cannot be found
    public static void productNotAvailable(PrintWriter out) {        
        out.println("                <h1>WE'RE SORRY!</h1><h2>The following item you were looking for does not exist.</h2><h2>Please try again.</h2><img src='images/sadface.png' width='420' height='420'/>");
    }
}
