/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helperpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.*;
import javax.servlet.RequestDispatcher;

/**
 *
 * @author Felipe Corona
 */
public class ProcessCheckoutServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */

    // Create New Connection
    private Connection getConnection() throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
    	Class.forName("com.mysql.jdbc.Driver").newInstance();
        return DriverManager.getConnection(MyConstants.SQL_URL, MyConstants.USERNAME, MyConstants.PASSWORD);
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {        
        PrintWriter out = null;
        Connection dbcon = null;
        HttpSession session = request.getSession(true);
        
        HashMap<Integer, Integer> itemsInCart = (HashMap<Integer,Integer>)session.getAttribute("itemsInCart");
        if (itemsInCart == null) {
            itemsInCart = new HashMap<>();
            session.setAttribute("itemsInCart", itemsInCart);
        }
        
        try {
            response.setContentType("text/html;charset=UTF-8");
            out = response.getWriter();
            
            dbcon = getConnection();
            
            // Update shopping cart
            if (request.getParameter("update") != null) {
                // Update Shopping Cart
                Set<Integer> productIDs = ((HashMap<Integer,Integer>)itemsInCart.clone()).keySet();
                for (Integer productID: productIDs) {
                    String productIDParam = "product-" + productID;
                    String productIDValueString = request.getParameter(productIDParam);
                    
                    if (Func_ParseHelper.stringIsInt(productIDValueString)) {
                        int productIDValue = Integer.parseInt(productIDValueString);
                        if (productIDValue == 0) {
                            itemsInCart.remove(productID);
                        } else {
                            itemsInCart.put(productID, productIDValue);
                        }                        
                    }
                }
                session.setAttribute("itemsInCart", itemsInCart);
                // Store already inputted data into a temporary session attribute... 
                storeTemporaryUserInputs(request, response);
                Func_Redirector.goToSiteReplace(out, "checkout");
            }
            // Submit order
            else if (request.getParameter("submit") != null) {
                validateAndSubmitInfo(request, response, out, dbcon);
            }
            // Why are you on this page?... Go back!
            else {
                Func_Redirector.goBack(out);
            }
        } catch (Exception ex) {
//            out.println("ERROR: " + ex);
        } finally {
            if (dbcon != null) {try {dbcon.close();} catch (SQLException e) {}}
            if (out != null) {out.close();}
        }
    }
    
    private void jsInvalidInput(PrintWriter out, String input) {
        out.println("<script>window.history.back(); window.history.go(0); alert('" + input + "');</script>");
    }
    
    protected void validateAndSubmitInfo(HttpServletRequest request, HttpServletResponse response, PrintWriter out, Connection conn) throws ServletException, IOException {
        HttpSession session = request.getSession(true);
        HashMap<Integer, Integer> itemsInCart = (HashMap<Integer,Integer>)session.getAttribute("itemsInCart");        

        // # of items in cart
        String numInCart = request.getParameter("numInCart");
        
        // User inputs
        String firstname = request.getParameter("firstname");
        String lastname = request.getParameter("lastname");
        String phone = request.getParameter("phone");
        String email = request.getParameter("email");
        String shippingAddress = request.getParameter("shippingAddress");
        String zipCode = request.getParameter("zipCode");
        String city = request.getParameter("city");
        String state = request.getParameter("state");
        String creditCard = request.getParameter("creditCard");
        String shippingMethod = request.getParameter("shippingMethod");
        
        // non-user input
        String price = request.getParameter("price");
        String totalprice = request.getParameter("totalprice");
        
        if (itemsInCart.isEmpty()) {
            storeTemporaryUserInputs(request, response);
            jsInvalidInput(out, "Your shopping cart is empty!");
            return;
        }
        if (!isValidName(firstname)) {
            storeTemporaryUserInputs(request, response);
            jsInvalidInput(out, "Not a valid first name format.");
            return;
        }
        if (!isValidName(lastname)) {
            storeTemporaryUserInputs(request, response);
            jsInvalidInput(out, "Not a valid last name format.");
            return;
        }
        if (!isValidPhone(phone)) {
            storeTemporaryUserInputs(request, response);
            jsInvalidInput(out, "Invalid phone number format.\\nTry ###-###-####");
            return;
        }
        if (!isValidEmail(email)) {
            storeTemporaryUserInputs(request, response);
            jsInvalidInput(out, "Invalid email format.\\nTry something@domain.extension");
            return;            
        }
        if (!isValidShippingAddress(shippingAddress)) {
            storeTemporaryUserInputs(request, response);
            jsInvalidInput(out, "Invalid Shipping Address format");
            return;          
        }
        if (!isValidZipCode(zipCode, conn)) {
            storeTemporaryUserInputs(request, response);
            jsInvalidInput(out, "Invalid Zip Code format.\\nTry a number between 0 and 99999 that actually exists.");
            return;    
        }
        if (!isValidCity(city)) {
            storeTemporaryUserInputs(request, response);
            jsInvalidInput(out, "Invalid city format.\\nCity must not be blank and must contain only letters.");
            return;             
        }
        if (!isValidState(state, conn)) {
            storeTemporaryUserInputs(request, response);
            jsInvalidInput(out, "Invalid state.");
            return;     
        }
        if (!isValidCreditCard(creditCard)) {
            storeTemporaryUserInputs(request, response);
            jsInvalidInput(out, "Not a valid credit card number format.\\nValid credit cards contain only numbers with length greater than 10.");
            return;             
        }
        if (!isValidShippingMethod(shippingMethod)) {
            storeTemporaryUserInputs(request, response);
            jsInvalidInput(out, "Invalid shipping method.");
            return;  
        }
        
        // Input data into DB
        PreparedStatement ps_insert = null;
        PreparedStatement ps = null;
        ResultSet rs_insert = null;
        int orderID = -1;
        
        String sql = "INSERT INTO orders (price, tax, total_price, first_name, last_name, phone_number, email, address, zipcode, city, state, creditcard, shipping) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            ps_insert = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps_insert.setString(1, price);
            ps_insert.setInt(2, 0);
            ps_insert.setString(3, totalprice);
            ps_insert.setString(4, firstname);
            ps_insert.setString(5, lastname);
            ps_insert.setString(6, phone);
            ps_insert.setString(7, email);
            ps_insert.setString(8, shippingAddress);
            ps_insert.setString(9, zipCode);
            ps_insert.setString(10, city);
            ps_insert.setString(11, state);
            ps_insert.setString(12, creditCard);
            ps_insert.setString(13, shippingMethod);
            ps_insert.executeUpdate(); 
            rs_insert = ps_insert.getGeneratedKeys();
            if (rs_insert.next()) {
                orderID = rs_insert.getInt(1);
            }
            // request.getSession(true) for itemsInCart then 0 it out. After that redirect to order summary
            if (orderID > -1) {
                ps = conn.prepareStatement("INSERT INTO products_in_orders (oid, pid, quantity) VALUES (?, ?, ?)");
                ps.setInt(1, orderID);
                
                for (Integer productID: itemsInCart.keySet()) {
                    ps.setInt(2, productID);
                    ps.setInt(3, itemsInCart.get(productID));
                    ps.executeUpdate();
                }
                // Order details completed. Clearing the cart and user info input.
                itemsInCart.clear();
                session.setAttribute("itemsInCart", itemsInCart);
                session.setAttribute("tempOrderInfo", null);
                
                // Redirect to order-details.jsp
                String orderDetailsURL = "order-details.jsp?id=" + orderID;
                RequestDispatcher rd = request.getRequestDispatcher(orderDetailsURL);
                rd.forward(request, response);
//                Func_Redirector.goToSiteReplace(out, orderDetailsURL);
            } else {
                jsInvalidInput(out, "Your order had failed to process :(");
            }
        } catch (Exception ex) {
//            out.println(ex);
        } finally {
            if (rs_insert != null) {try {rs_insert.close();} catch (SQLException e) {}}
            if (ps != null) {try {ps.close();} catch (SQLException e) {}}
            if (ps_insert != null) {try {ps_insert.close();} catch (SQLException e) {}}
        }

    }
    
    protected void storeTemporaryUserInputs(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(true);
        
        HashMap<String, String> tempOrderInfo = (HashMap<String, String>)session.getAttribute("tempOrderInfo");
        if (tempOrderInfo == null) {
            tempOrderInfo = new HashMap<>();
        }
        tempOrderInfo.put("firstname", request.getParameter("firstname"));
        tempOrderInfo.put("lastname", request.getParameter("lastname"));
        tempOrderInfo.put("phone", request.getParameter("phone"));
        tempOrderInfo.put("email", request.getParameter("email"));
        tempOrderInfo.put("shippingAddress", request.getParameter("shippingAddress"));
        tempOrderInfo.put("zipCode", request.getParameter("zipCode"));
        tempOrderInfo.put("city", request.getParameter("city"));
        tempOrderInfo.put("state", request.getParameter("state"));
        tempOrderInfo.put("creditCard", request.getParameter("creditCard"));
        tempOrderInfo.put("shippingMethod", request.getParameter("shippingMethod"));
        session.setAttribute("tempOrderInfo", tempOrderInfo);
    }
    
    private boolean isValidName(String name)
    {    
        return name.length() > 0 && name.matches("^[a-zA-Z ]+$");
    }
    
    private boolean isValidPhone(String phone)
    {
        return phone.matches("^\\(?([0-9]{3})\\)?[-+ ]?([0-9]{3})[-+ ]?([0-9]{4})$");
    }
    
    private boolean isValidEmail(String email)
    {
        return email.matches("\\S+@\\S+\\.\\S+");
    }
    
    private boolean isValidShippingAddress(String shippingAddress)
    {
        return shippingAddress.length() > 0;
    }
    
    private boolean isValidZipCode(String zipCode, Connection conn)
    {
        PreparedStatement ps1 = null;
        PreparedStatement ps2 = null;
        ResultSet rs1 = null;
        ResultSet rs2 = null;
        boolean valid = false;
        
        try {
            ps1 = conn.prepareStatement("SELECT zipcode FROM tax_rates WHERE zipcode=?");
            ps1.setString(1, zipCode);
            rs1 = ps1.executeQuery();
            if (rs1.next()) {
                valid = true;
            }
            if (!valid) {
                ps2 = conn.prepareStatement("SELECT zip FROM zip_codes WHERE zip=?");
                ps2.setString(1, zipCode);
                rs2 = ps2.executeQuery();
                if (rs2.next()) {
                    valid = true;
                }
            }
        } catch(Exception e) {} finally {
            if (rs1 != null) {try {rs1.close();} catch (SQLException e) {}}
            if (rs2 != null) {try {rs2.close();} catch (SQLException e) {}}        
            if (ps1 != null) {try {ps1.close();} catch (SQLException e) {}}
            if (ps2 != null) {try {ps2.close();} catch (SQLException e) {}}
        }
        return valid;
    }
    
    private boolean isValidCity(String city)
    {
        return city.matches("^[a-zA-Z ]*$");
    }
    
    private boolean isValidState(String state, Connection conn)
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean valid = false;
        
        try {
            ps = conn.prepareStatement("SELECT DISTINCT state FROM zip_codes WHERE state=?");
            ps.setString(1, state);
            rs = ps.executeQuery();
            if (rs.next()) {
                valid = true;
            }
        } catch(Exception e) {} finally {
            if (rs != null) {try {rs.close();} catch (SQLException e) {}}
            if (ps != null) {try {ps.close();} catch (SQLException e) {}}
        }
        return valid;        
    }
    
    private boolean isValidCreditCard(String creditCard)
    {
        if (creditCard.length() > 10) {
            return creditCard.matches("([0-9]+$)"); 
        }
        return false;
    }
    
    private boolean isValidShippingMethod(String shippingMethod)
    {
        return shippingMethod.equals("0") || shippingMethod.equals("4.99") || shippingMethod.equals("9.99");
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
