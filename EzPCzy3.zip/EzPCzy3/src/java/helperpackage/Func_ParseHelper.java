/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helperpackage;

/**
 *
 * @author Felipe Corona
 */
public class Func_ParseHelper {
    
    /*
    Takes a string and checks to see that the String can be parsed to an int
    Returns true or false whether it can be parsed to an int or not
    */
    public static boolean stringIsInt(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException ex) {
            return false;
        }
    }
    public static boolean stringIsValid(String str){
        try{
            return (str.compareToIgnoreCase("desktops") == 0 || str.compareToIgnoreCase("laptops") == 0 || str.compareToIgnoreCase("accessories") == 0);
        }catch (NumberFormatException ex)
        {
            return false;
        }
    }
}
