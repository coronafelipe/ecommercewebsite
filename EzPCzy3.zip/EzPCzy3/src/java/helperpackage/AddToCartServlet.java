/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helperpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Felipe Corona
 */
public class AddToCartServlet extends HttpServlet {

    private Connection getConnection() throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
	return DriverManager.getConnection(MyConstants.SQL_URL, MyConstants.USERNAME, MyConstants.PASSWORD);
        
    }    
    
    private void jsInvalidInput(PrintWriter out, String input) {
        out.println("<script>window.history.back(); window.history.go(0); alert('" + input + "');</script>");
    }
    
    private void jsSuccessfulAdd(PrintWriter out, String site) {
        out.println("<script>window.location.replace('" + site + "'); alert('Product successfully added to cart!');</script>");
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Connection dbcon = null;
        PrintWriter out = null;
        ResultSet rs = null;
        PreparedStatement ps = null;
        
        boolean successful = false;
        
        response.setContentType("text/html;charset=UTF-8");
        out = response.getWriter();
        
        HttpSession session = request.getSession(true);
        
        HashMap<Integer, Integer> itemsInCart = (HashMap<Integer,Integer>)session.getAttribute("itemsInCart");
        if (itemsInCart == null) {
            itemsInCart = new HashMap<>();
            session.setAttribute("itemsInCart", itemsInCart);
        }
        
        String parameter = request.getParameter("id");
        try {
            dbcon = getConnection();
            ps = dbcon.prepareStatement("SELECT id FROM products WHERE id=?");
            ps.setString(1, parameter);
            rs = ps.executeQuery();
            if (rs.next()) {
                int parameter_num = rs.getInt("id");
                if (itemsInCart.containsKey(parameter_num)) {
                    int productAmount = itemsInCart.get(parameter_num);
                    productAmount++;
                    itemsInCart.put(parameter_num, productAmount);
                } else {
                    itemsInCart.put(parameter_num, 1);
                }
                session.setAttribute("itemsInCart", itemsInCart);
                successful = true;   
            }
            
            if (successful) {
                jsSuccessfulAdd(out, "product?id=" + parameter);
            } else {
                jsInvalidInput(out, "Invalid product ID or product cannot be added to the cart.");
            }      
        } catch (SQLException | InstantiationException | IllegalAccessException | ClassNotFoundException ex) {
            jsInvalidInput(out, "Invalid product ID or product cannot be added to the cart.");
        } finally {
            if (rs != null) {try {rs.close();} catch (SQLException e) {}}
            if (ps != null) {try {ps.close();} catch (SQLException e) {}}
            if (dbcon != null) {try {dbcon.close();} catch (SQLException e) {}}
            if (out != null) {out.close();}
        }            
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
