/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import helperpackage.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
//import java.util.logging.Level;
//import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
/**
 *
 * @author Felipe Corona
 */
public class ListProductsServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        Connection dbcon = null;
        PrintWriter out = null;
        
        try {
            response.setContentType("text/html;charset=UTF-8");
            out = response.getWriter();
            
            dbcon = getConnection();
            
            Func_HeaderFooterFiller.fillHead(out, new String[]{"CSS/master.css", "CSS/sales.css"}, 
                                                  new String[]{"JS/eventhandlers.js"});
            Func_HeaderFooterFiller.fillHeader(out);
            out.println("<div class=\"container\">");
            
            //testing include
            RequestDispatcher rd = request.getRequestDispatcher("/RecentlyViewed");
            rd.include(request, response);
            
            displayProducts(out, dbcon);
            
            out.println("</div>");
            out.println("<br/><br/><br/><br/>");
            Func_HeaderFooterFiller.fillFooter(out);
        } catch (Exception ex) {
            out.println("ERROR: " + ex);
        } finally {
            if (dbcon != null) {try {dbcon.close();} catch (SQLException e) {}}
            if (out != null) {out.close();}
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Display a list of products for the homepage.";
    }// </editor-fold>

    
    private Connection getConnection() throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
	return DriverManager.getConnection(MyConstants.SQL_URL, MyConstants.USERNAME, MyConstants.PASSWORD);
    }
    
    private void displayProducts(PrintWriter out, Connection conn) throws SQLException{
        Statement statement = conn.createStatement();
        ResultSet rs = statement.executeQuery("SELECT id FROM products ORDER BY clicks DESC LIMIT 3"); //hottest products!
        
        Statement statement2 = conn.createStatement();
        ResultSet rs2 = statement2.executeQuery("SELECT id FROM products ORDER BY id DESC LIMIT 3"); // newest products!
        
        ArrayList<Integer> hottestProductIds = new ArrayList<>();
        while(rs.next()){
            hottestProductIds.add(rs.getInt("id"));
        }
        
        ArrayList<Integer> newestProductIds = new ArrayList<>();
        while(rs2.next()){
            newestProductIds.add(rs2.getInt("id"));
        }
        
        try {
            out.println("<h1>Newest Items</h2>");
            MultipleProductWriter.write(newestProductIds, out);
            out.println("<h1>Hottest Items</h1>");
            MultipleProductWriter.write(hottestProductIds, out);
        } catch (InstantiationException | IllegalAccessException | ClassNotFoundException ex) {
            out.println(ex);
        }
        
    }
}
